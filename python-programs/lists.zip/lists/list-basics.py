l1 = [1,2,3,4,5,6,7,8,9,10]

# Access elements of list using for loop
# for ele in l1:
#     print(ele)

# Access elements of a list using index
# l = len(l1)
# indexes = range(l)
# for i in indexes:
#     print(l1[i])

# print only even numbers from list
# for ele in l1:
#     if ele%2 == 0:
#         print(ele)

# print square of even and cube of odd
# for ele in l1:
#     if ele%2 == 0:
#         print(ele**2)
#     else:
#         print(ele**3)

# WAP to find square of elements at even index and cube of elements at odd index
# for i in range(len(l1)):
#     if i%2 == 0:
#         print(l1[i]**2)
#     else:
#         print(l1[i]**3)

