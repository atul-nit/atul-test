# t1 = (1,3,5)

# invalid operation
# t1[0] = 7

# empty tuple
# t1 = ()

# tuple with one element
# t1 = 12,
# t2 = (2)
# print(type(t1))
# print(type(t2))

# t1 = 10,20,30
# print(t1)
#
# t2 = 23,56
# a,b = t2
# print(a,b)

# t1 = 1,2,3
# t2 = 30,40
# t3 = t1 + t2
# t4 = t1 * 2
# print(t1)
# print(t2)
# print(t3)
# print(t4)

# t1 = (10,20)
# t = list(t1)
# t.append(30)
# t1 = tuple(t)
# print(t1)

# t1 = tuple(range(5, 101, 5))
# print(t1)
