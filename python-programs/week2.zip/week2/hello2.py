# l1=[3,1,-1,9,2]
# l2=[11,22,0,-5,18,1,72,3,9,6,-6,22,23]
# for i in range(len(l1)):
#     count=0
#     for j in range(len(l2)):
#         if (l1[i]<l2[j]):
#             count+=1
#         else:
#             pass
#
#     print("numbers greater than",l1[i],"is:",count)

def show():
    print("show from hello 2")

