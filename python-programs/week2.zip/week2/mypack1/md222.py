def show_score():
    print("score is 90")
