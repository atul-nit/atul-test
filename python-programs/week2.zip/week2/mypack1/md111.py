def show_message( s ):
    print(s)
