# l1 = list(range(25, 40, 5))
# print(l1)
# l1 = [1,3,5,7,9]
# iterate using elements
# for ele in l1:
#     print(ele)
# print("after for loop")

# iterate using index
# for i in range(len(l1)):
#     print("{} -> {}".format(i, l1[i]))

# l1 = [1,2,3,4,5]
# print square of even elements and cube of odd elements
# for ele in l1:
#     if ele%2 == 0:
#         print(ele**2)
#     else:
#         print(ele**3)

# print square of elements at even index and cube of elements at odd index
# l1 = [1,2,3,4,5]
# for i in range(len(l1)):
#     if i%2 == 0:
#         print(l1[i]**2)
#     else:
#         print(l1[i]**3)

# for i in range(1,21):
#     if i%5 == 0:
#         i += 1
#         continue
#     if i%3 == 0:
#         print(i)
#     i += 1
"""
sinduja.ramaraj
abhiachugayi
siddappavishu@gmail.com
changulandareshma@gmail
"""


