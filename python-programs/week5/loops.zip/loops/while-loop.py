# i = 1
# while i <= 10:
#     print(i)
#     i += 1

# Print first 10 multiples of 5
# i = 1
# while i <= 10:
#     print(5 * i)
#     i += 1

# Print multiples of 5 from 25 to 75
# i = 25
# while i <= 75:
#     print(i)
#     i += 5

# i = 11
# while i <= 5:
#     print(i)
#     i += 1
# else:
#     print("else part of while")

# Infinite loop with condition

# while True:
#     name = input("enter name: ")
#     print("hello ", name)
#     ch = input("Do you wish to continue(y/n): ")
#     if ch == 'n' or ch == 'N':
#         print("Thanks....")
#         break


# i = 1
# while i <= 20:
#     if i%5 == 0:
#         i += 1
#         continue
#     if i%3 == 0:
#         print(i)
#     i += 1

# i = 1
# while i < 4:
#     j = 0
#     print(i)
#     while j < i:
#         j += 1
#         if j%2 == 0:
#             continue
#         if j%5 == 0:
#             break
#         print(j)
#     i += 1

"""
1.    *
    * * *
   * * * * *
"""


