A = {1,3,5}
B = {0,7,1,9,5,4}

# union
# aUb = A|B
# print(aUb)
# print(A.union(B))
# print(B.union(A))


# intersection
# aIb = A&B
# print(aIb)
# print(A)
# print(A.intersection(B))
# print(A)
# A.intersection_update(B)
# print(A)

# difference
# print(A-B)
# print(B-A)
# print(A.difference(B))
# A.difference_update(B)
# print(A)

# symmetric difference
# print(A^B)
# print((A|B) - (A&B))
# print((A-B)|(B-A))
# print(A.symmetric_difference(B))
# A.symmetric_difference_update(B)
# print(A)

# compare sets
# s1 = {1,2,3,4,5,6,7,8,9,10}
# sodd = {1,3,5}
# seven = {2,4,12}
# if sodd <= s1:
#     print("sodd is subset of s1")
# else:
#     print("sodd is not a subset of s1")
# if seven <= s1:
#     print("seven is subset of s1")
# else:
#     print("seven is not a subset of s1")
# if s1 >= sodd:
#     print("s1 is superset of sodd")