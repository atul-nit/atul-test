# normal set
# normal_set = set(["a", "b","c"])
# s1 = {'a','b','c'}
# print(normal_set)
# print(s1)

# can't add mutable elements in set
# st1 = {(1,2), (3,4)}  # work
# # sl1 = {[1,2], [3,4]}   # won't work
# sd1 = {{"id":1,"name":"Peter"}}  # won't work

# frozen set
# fs1 = frozenset(["a", "b","c"])
# print(fs1)


# Accesing elements
# s1 = {1,4,6,8}
# for ele in s1:
#     print(ele)

# Adding items to set
# s1.add(9)
# print(s1)

# Set will not add duplicate element
# s1.add(8)
# print(s1)


# removing elements
# s1.discard(8)
# print(s1)

# find length of set
# print(len(s1))